#!/usr/bin/python3
# -*- coding:utf-8 -*-
"""
@author: zhangyuhao
@file: road_network_information_generate.py
@time: 2022/2/7 下午6:55
@email: yuhaozhang76@gmail.com
@desc: 
"""
import config

def generate_square_map():
